package com.tencent.multiplayersdk;

public class ShareUtil {

}
