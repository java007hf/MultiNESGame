package com.tencent.multiplayersdk;

class EventObj {
	public Object obj;
	public byte[] bytes;
	
	public EventObj(Object object, byte[] b) {
		obj = object;
		bytes = b;
	}
}
