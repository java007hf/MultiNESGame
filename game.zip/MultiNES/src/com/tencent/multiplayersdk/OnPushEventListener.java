package com.tencent.multiplayersdk;

public interface OnPushEventListener {
//	public void 
}
