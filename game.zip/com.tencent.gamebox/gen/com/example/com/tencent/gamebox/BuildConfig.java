/** Automatically generated file. DO NOT MODIFY */
package com.example.com.tencent.gamebox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}