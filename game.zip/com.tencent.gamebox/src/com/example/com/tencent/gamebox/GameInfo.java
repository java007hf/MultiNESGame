package com.example.com.tencent.gamebox;

import java.io.Serializable;
import java.util.List;

public class GameInfo implements Serializable {
	public String broadcastIp = "239.255.255.250";
	public int broadcastPort = 4445;
	
	public String name;
	public String auth;
}
