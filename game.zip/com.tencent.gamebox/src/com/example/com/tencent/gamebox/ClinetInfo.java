package com.example.com.tencent.gamebox;

import java.io.Serializable;

public class ClinetInfo implements Serializable {

}
